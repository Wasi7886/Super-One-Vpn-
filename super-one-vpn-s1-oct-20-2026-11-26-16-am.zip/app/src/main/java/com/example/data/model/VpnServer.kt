package com.example.data.model

enum class ServerCategory(val label: String, val icon: String) {
    ALL("All Servers", "🌐"),
    RECOMMENDED("Recommended", "⚡"),
    SPORTS("Sports & Streaming", "⚽"),
    WHATSAPP("WhatsApp & VoIP", "💬")
}

data class VpnServer(
    val id: String,
    val country: String,
    val city: String,
    val flagEmoji: String,
    val pingMs: Int,
    val ipAddress: String,
    val statusTag: String,
    val category: ServerCategory = ServerCategory.ALL,
    val isRecommended: Boolean = false,
    val isPremium: Boolean = false,
    val protocol: String = "WireGuard"
) {
    val displayName: String
        get() = "$country — $city"
}

object DefaultServers {
    val servers = listOf(
        VpnServer(
            id = "sg-01",
            country = "Singapore",
            city = "Singapore",
            flagEmoji = "🇸🇬",
            pingMs = 12,
            ipAddress = "103.45.122.88",
            statusTag = "Recommended • Lowest Ping",
            category = ServerCategory.RECOMMENDED,
            isRecommended = true,
            isPremium = false,
            protocol = "WireGuard"
        ),
        VpnServer(
            id = "wg-ubuntu",
            country = "WireGuard (Ubuntu)",
            city = "VPN: 10.0.0.1/24",
            flagEmoji = "⚡",
            pingMs = 14,
            ipAddress = "160.200.2.1",
            statusTag = "External: 160.200.2.1 • WireGuard",
            category = ServerCategory.RECOMMENDED,
            isRecommended = true,
            isPremium = false,
            protocol = "WireGuard"
        ),
        VpnServer(
            id = "us-01",
            country = "United States",
            city = "New York",
            flagEmoji = "🇺🇸",
            pingMs = 48,
            ipAddress = "142.250.190.46",
            statusTag = "ESPN & Live Sports 4K",
            category = ServerCategory.SPORTS,
            isRecommended = true,
            isPremium = false,
            protocol = "WireGuard"
        ),
        VpnServer(
            id = "de-01",
            country = "Germany",
            city = "Frankfurt",
            flagEmoji = "🇩🇪",
            pingMs = 62,
            ipAddress = "185.220.101.5",
            statusTag = "Zero Logs • High Bandwidth",
            category = ServerCategory.ALL,
            isRecommended = true,
            isPremium = false,
            protocol = "V2Ray"
        ),
        VpnServer(
            id = "ae-01",
            country = "United Arab Emirates",
            city = "Dubai",
            flagEmoji = "🇦🇪",
            pingMs = 74,
            ipAddress = "94.200.12.110",
            statusTag = "WhatsApp Calling Unlocked",
            category = ServerCategory.WHATSAPP,
            isRecommended = true,
            isPremium = false,
            protocol = "WireGuard"
        ),
        VpnServer(
            id = "jp-01",
            country = "Japan",
            city = "Tokyo",
            flagEmoji = "🇯🇵",
            pingMs = 89,
            ipAddress = "133.242.18.22",
            statusTag = "Ultra Low Jitter",
            category = ServerCategory.ALL,
            isRecommended = false,
            isPremium = false,
            protocol = "WireGuard"
        ),
        VpnServer(
            id = "gb-01",
            country = "United Kingdom",
            city = "London",
            flagEmoji = "🇬🇧",
            pingMs = 95,
            ipAddress = "51.15.89.231",
            statusTag = "Premier League HD Sports",
            category = ServerCategory.SPORTS,
            isRecommended = true,
            isPremium = false,
            protocol = "WireGuard"
        ),
        VpnServer(
            id = "sa-01",
            country = "Saudi Arabia",
            city = "Riyadh",
            flagEmoji = "🇸🇦",
            pingMs = 45,
            ipAddress = "212.138.10.65",
            statusTag = "Gulf Ultra Route",
            category = ServerCategory.WHATSAPP,
            isRecommended = true,
            isPremium = false,
            protocol = "V2Ray"
        ),
        VpnServer(
            id = "in-01",
            country = "India",
            city = "Mumbai",
            flagEmoji = "🇮🇳",
            pingMs = 60,
            ipAddress = "103.21.244.0",
            statusTag = "Hotstar Cricket Live Stream",
            category = ServerCategory.SPORTS,
            isRecommended = false,
            isPremium = false,
            protocol = "WireGuard"
        )
    )

    val defaultServer: VpnServer = servers.first()
}
