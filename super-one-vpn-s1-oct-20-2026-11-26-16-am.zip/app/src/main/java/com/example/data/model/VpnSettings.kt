package com.example.data.model

enum class OptimizationMode(val title: String, val subtitle: String, val icon: String) {
    AUTO("S1 Turbo Auto", "S1 Private DNS + WireGuard routing", "⚡"),
    WHATSAPP("WhatsApp & VoIP Turbo", "Anti-censorship UDP & zero jitter for calls", "💬"),
    SPORTS("Sports & 4K Streaming", "Unbuffered live streams, zero packet drop", "⚽"),
    MAX_PRIVACY("Maximum Privacy", "V2Ray Stealth + ChaCha20-Poly1305 encryption", "🛡️")
}

data class VpnSettings(
    val killSwitch: Boolean = false,
    val autoConnectWifi: Boolean = true,
    val controlCentreTile: Boolean = true,
    val notifications: Boolean = true,
    val isDarkMode: Boolean = true,
    val s1TurboMode: Boolean = true,
    val protocol: String = "WireGuard",
    val optimizationMode: OptimizationMode = OptimizationMode.AUTO,
    val isPremium: Boolean = false
)
