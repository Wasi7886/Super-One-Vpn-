package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.VpnRepository
import com.example.ui.components.InterstitialAdDialog
import com.example.ui.navigation.Screen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ServerListScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.SuperOneVpnTheme

class MainActivity : ComponentActivity() {

    private val repository by lazy { VpnRepository.getInstance(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by repository.uiState.collectAsStateWithLifecycle()
            val settings by repository.settings.collectAsStateWithLifecycle()

            var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }
            var showInterstitialAd by remember { mutableStateOf(false) }

            // Listen for disconnect events to show interstitial ad on free tier
            LaunchedEffect(Unit) {
                repository.showInterstitialEvent.collect {
                    if (!settings.isPremium) {
                        showInterstitialAd = true
                    }
                }
            }

            // Listen for speed optimization events to show Toast
            LaunchedEffect(Unit) {
                repository.speedToastEvent.collect { message ->
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                }
            }

            SuperOneVpnTheme(darkTheme = settings.isDarkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            if (targetState is Screen.Splash) {
                                fadeIn() togetherWith fadeOut()
                            } else if (targetState is Screen.ServerList || targetState is Screen.Settings) {
                                (slideInHorizontally { width -> width } + fadeIn()) togetherWith
                                        (slideOutHorizontally { width -> -width / 2 } + fadeOut())
                            } else {
                                (slideInHorizontally { width -> -width / 2 } + fadeIn()) togetherWith
                                        (slideOutHorizontally { width -> width } + fadeOut())
                            }
                        },
                        label = "screen_transition"
                    ) { screen ->
                        when (screen) {
                            is Screen.Splash -> {
                                SplashScreen(
                                    onFinished = { currentScreen = Screen.Home }
                                )
                            }
                            is Screen.Home -> {
                                HomeScreen(
                                    uiState = uiState,
                                    settings = settings,
                                    onToggleConnection = { repository.toggleConnection() },
                                    onOptimizeSpeed = { repository.optimizeSpeed() },
                                    onNavigateToServers = { currentScreen = Screen.ServerList },
                                    onNavigateToSettings = { currentScreen = Screen.Settings },
                                    onOptimizationModeChange = { repository.setOptimizationMode(it) },
                                    onUpgradeToPremium = { repository.upgradeToPremium() }
                                )
                            }
                            is Screen.ServerList -> {
                                ServerListScreen(
                                    currentServer = uiState.selectedServer,
                                    onSelectServer = { repository.selectServer(it) },
                                    onNavigateBack = { currentScreen = Screen.Home }
                                )
                            }
                            is Screen.Settings -> {
                                SettingsScreen(
                                    settings = settings,
                                    onKillSwitchChange = { repository.setKillSwitch(it) },
                                    onAutoConnectChange = { repository.setAutoConnect(it) },
                                    onNotificationsChange = { repository.setNotifications(it) },
                                    onDarkModeChange = { repository.setDarkMode(it) },
                                    onS1TurboModeChange = { repository.setS1TurboMode(it) },
                                    onProtocolChange = { repository.setProtocol(it) },
                                    onUpgradeToPremium = { repository.upgradeToPremium() },
                                    onNavigateBack = { currentScreen = Screen.Home }
                                )
                            }
                        }
                    }

                    // Interstitial ad triggered upon disconnect
                    if (showInterstitialAd) {
                        InterstitialAdDialog(
                            onDismiss = { showInterstitialAd = false },
                            onGoPro = {
                                showInterstitialAd = false
                                repository.upgradeToPremium()
                            }
                        )
                    }
                }
            }
        }
    }
}
