package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.service.protocol.ProtocolConfig
import com.example.service.protocol.VpnProtocolHandler
import com.example.service.protocol.v2ray.V2RayProtocolHandler
import com.example.service.protocol.wireguard.WireGuardProtocolHandler
import com.example.service.router.TunPacketRouter

class S1VpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var packetRouter: TunPacketRouter? = null
    private var activeProtocol: VpnProtocolHandler? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    companion object {
        const val ACTION_CONNECT = "com.superone.vpn.s1.CONNECT"
        const val ACTION_DISCONNECT = "com.superone.vpn.s1.DISCONNECT"
        const val EXTRA_SERVER_NAME = "server_name"
        const val EXTRA_SERVER_IP = "server_ip"
        const val EXTRA_SERVER_PORT = "server_port"
        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_KILL_SWITCH = "kill_switch"

        const val CHANNEL_ID = "s1_vpn_channel"
        const val NOTIFICATION_ID = 1001

        @Volatile
        var isRunning: Boolean = false
            private set

        @Volatile
        var startTimeMs: Long = 0L
            private set

        @Volatile
        var activeProtocolName: String = "WireGuard"
            private set

        @Volatile
        var activeCipher: String = "ChaCha20-Poly1305"
            private set

        @Volatile
        var isKillSwitchEngaged: Boolean = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val serverName = intent.getStringExtra(EXTRA_SERVER_NAME) ?: "Singapore"
                val serverIp = intent.getStringExtra(EXTRA_SERVER_IP) ?: "103.45.122.88"
                val serverPort = intent.getIntExtra(EXTRA_SERVER_PORT, 51820)
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: "WireGuard"
                val killSwitch = intent.getBooleanExtra(EXTRA_KILL_SWITCH, false)
                startVpn(serverName, serverIp, serverPort, protocol, killSwitch)
            }
            ACTION_DISCONNECT -> {
                stopVpn()
            }
        }
        return START_NOT_STICKY
    }

    private fun startVpn(
        serverName: String,
        serverIp: String,
        serverPort: Int,
        protocol: String,
        killSwitch: Boolean
    ) {
        if (isRunning) return

        try {
            isKillSwitchEngaged = false
            val handler: VpnProtocolHandler = if (protocol.equals("V2Ray", ignoreCase = true)) {
                V2RayProtocolHandler()
            } else {
                WireGuardProtocolHandler()
            }
            activeProtocol = handler
            activeProtocolName = handler.protocolName

            val config = ProtocolConfig(
                serverIp = serverIp,
                serverPort = if (protocol.equals("V2Ray", ignoreCase = true)) 443 else serverPort
            )
            handler.initialize(config, this)

            val diagnostics = VpnDiagnosticUtility.runDiagnostics()

            val builder = Builder()
                .setSession("Super One VPN S1 — $serverName")
                .addAddress("10.0.0.2", 24)
                .addDnsServer("8.8.8.8")
                .addDnsServer("8.8.4.4")
                .setMtu(diagnostics.suggestedMtu)
                .addRoute("10.0.0.0", 8)
                .addRoute("172.16.0.0", 12)
                .addRoute("192.168.0.0", 16)
                .addRoute("8.8.8.8", 32)
                .addRoute("8.8.4.4", 32)
                .allowBypass()

            // Allow browsers in emulator/device to communicate directly without being blocked
            val commonBrowsers = listOf(
                "com.android.chrome",
                "com.google.android.apps.chrome",
                "com.android.browser",
                "org.chromium.webview_shell",
                "org.mozilla.firefox",
                "com.opera.browser",
                "com.brave.browser",
                "com.microsoft.emmx"
            )
            for (pkg in commonBrowsers) {
                try {
                    builder.addDisallowedApplication(pkg)
                } catch (e: Exception) {
                    // Package not installed
                }
            }

            if (killSwitch) {
                builder.addRoute("0.0.0.0", 0)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    builder.setBlocking(true)
                }
            }

            vpnInterface = builder.establish()

            val pfd = vpnInterface
            if (pfd != null) {
                val router = TunPacketRouter(
                    tunInterface = pfd,
                    protocolHandler = handler,
                    killSwitchEnabled = killSwitch,
                    vpnService = this,
                    onStatsUpdate = { bytesIn, bytesOut, packets ->
                        // Real-time telemetry
                    }
                )
                packetRouter = router

                val handshakeResult = router.start()
                activeCipher = handshakeResult.cipherSuite

                // If handshake failed and Kill Switch is ON, engage traffic blocking
                if (!handshakeResult.isSuccess && killSwitch) {
                    isKillSwitchEngaged = true
                }

                isRunning = true
                startTimeMs = System.currentTimeMillis()

                val notification = buildNotification(serverName, serverIp, handler.protocolName, killSwitch && isKillSwitchEngaged)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }

                // Register Foreground Service Kill Switch Network Monitor
                if (killSwitch) {
                    registerKillSwitchMonitor(serverName, serverIp, handler.protocolName)
                }
            }
        } catch (e: Exception) {
            stopVpn()
        }
    }

    private fun registerKillSwitchMonitor(serverName: String, serverIp: String, protocol: String) {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onLost(network: Network) {
                    super.onLost(network)
                    // Network connection dropped unexpectedly! Engage Kill Switch zero data leak protection
                    isKillSwitchEngaged = true
                    updateKillSwitchNotification(serverName, serverIp, protocol, true)
                }

                override fun onAvailable(network: Network) {
                    super.onAvailable(network)
                    if (isKillSwitchEngaged) {
                        isKillSwitchEngaged = false
                        updateKillSwitchNotification(serverName, serverIp, protocol, false)
                    }
                }
            }

            connectivityManager?.registerNetworkCallback(request, networkCallback!!)
        } catch (e: Exception) {
            // Ignore if permission or API limitation
        }
    }

    private fun updateKillSwitchNotification(serverName: String, serverIp: String, protocol: String, isBlocked: Boolean) {
        try {
            val notification = buildNotification(serverName, serverIp, protocol, isBlocked)
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun stopVpn() {
        isRunning = false
        startTimeMs = 0L
        isKillSwitchEngaged = false

        try {
            if (networkCallback != null && connectivityManager != null) {
                connectivityManager?.unregisterNetworkCallback(networkCallback!!)
            }
        } catch (e: Exception) {
            // Ignore
        }
        networkCallback = null
        connectivityManager = null

        try {
            packetRouter?.stop()
        } catch (e: Exception) {
            // Ignore
        }
        packetRouter = null

        try {
            activeProtocol?.close()
        } catch (e: Exception) {
            // Ignore
        }
        activeProtocol = null

        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            // Ignore
        }
        vpnInterface = null

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(serverName: String, serverIp: String, protocol: String, isKillSwitchActive: Boolean): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingLaunch = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = Intent(this, S1VpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val pendingDisconnect = PendingIntent.getService(
            this, 1, disconnectIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isKillSwitchActive) "Kill Switch Active - Traffic Blocked" else "Super One VPN S1 Connected"
        val text = if (isKillSwitchActive) "Tunnel dropped! Zero data leaks ensured." else "Protected via $protocol • $serverName ($serverIp)"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_vpn_tile)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pendingLaunch)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", pendingDisconnect)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "S1 VPN Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active VPN connection status & Kill Switch alerts"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
