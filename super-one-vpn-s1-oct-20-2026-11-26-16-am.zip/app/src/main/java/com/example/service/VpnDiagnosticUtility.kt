package com.example.service

import android.os.Build
import android.util.Log

data class VpnDiagnosticsResult(
    val isEmulator: Boolean,
    val suggestedMtu: Int,
    val dnsBypassActive: Boolean,
    val diagnosticMessage: String
)

object VpnDiagnosticUtility {

    private const val TAG = "VpnDiagnosticUtility"

    /**
     * Detects if the app is running within an Android Emulator environment
     */
    fun checkIsEmulator(): Boolean {
        return (Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.BOARD == "unknown"
                || Build.HARDWARE.contains("goldfish")
                || Build.HARDWARE.contains("ranchu")
                || Build.PRODUCT.contains("sdk")
                || Build.PRODUCT.contains("google_sdk")
                || Build.PRODUCT.contains("sdk_gphone"))
    }

    /**
     * Runs comprehensive connectivity diagnostics for S1 VPN service
     */
    fun runDiagnostics(): VpnDiagnosticsResult {
        val emulator = checkIsEmulator()
        val optimalMtu = if (emulator) 1420 else 1500
        val dnsBypass = true

        val message = if (emulator) {
            "S1 Diagnostics: Emulator environment detected. Optimal MTU set to $optimalMtu, S1 Private DNS (8.8.8.8) bypass active with TCP socket proxy relay."
        } else {
            "S1 Diagnostics: Physical device detected. Optimal MTU set to $optimalMtu, direct high-speed WireGuard tunnel active."
        }

        Log.i(TAG, message)
        return VpnDiagnosticsResult(
            isEmulator = emulator,
            suggestedMtu = optimalMtu,
            dnsBypassActive = dnsBypass,
            diagnosticMessage = message
        )
    }
}
