package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.VpnRepository

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val repository = VpnRepository.getInstance(context)
            if (repository.settings.value.autoConnectWifi) {
                repository.connect()
            }
        }
    }
}
