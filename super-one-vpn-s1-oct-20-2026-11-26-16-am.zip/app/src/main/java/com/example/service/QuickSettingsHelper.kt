package com.example.service

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.os.Build
import com.example.R

object QuickSettingsHelper {

    /**
     * Attempts to programmatically request adding S1 VPN to the Android Quick Settings panel (Android 13+)
     */
    fun requestAddTile(
        context: Context,
        onResult: (isPromptShown: Boolean) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            try {
                val statusBarManager = context.getSystemService(StatusBarManager::class.java)
                val component = ComponentName(context, S1TileService::class.java)
                statusBarManager.requestAddTileService(
                    component,
                    context.getString(R.string.quick_settings_tile_label),
                    Icon.createWithResource(context, R.drawable.ic_vpn_tile),
                    context.mainExecutor
                ) { resultCode ->
                    // Result: TILE_ADD_REQUEST_RESULT_TILE_ADDED, TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED, etc.
                }
                onResult(true)
                return
            } catch (e: Exception) {
                // Fallback to manual guide dialog
            }
        }
        onResult(false)
    }
}
