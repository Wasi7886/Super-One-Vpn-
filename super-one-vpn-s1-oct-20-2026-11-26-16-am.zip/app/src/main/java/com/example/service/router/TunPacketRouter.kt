package com.example.service.router

import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.example.service.protocol.HandshakeResult
import com.example.service.protocol.VpnProtocolHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class TunPacketRouter(
    private val tunInterface: ParcelFileDescriptor,
    private val protocolHandler: VpnProtocolHandler,
    private val killSwitchEnabled: Boolean,
    private val vpnService: VpnService? = null,
    private val onStatsUpdate: (bytesIn: Long, bytesOut: Long, packets: Long) -> Unit
) {
    private val isRunning = AtomicBoolean(false)
    private var workerJob: Job? = null
    private var keepaliveJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val totalBytesIn = AtomicLong(0L)
    private val totalBytesOut = AtomicLong(0L)
    private val totalPackets = AtomicLong(0L)

    private var dnsSocket: DatagramSocket? = null
    private var dnsServerAddress: InetAddress? = null

    init {
        try {
            dnsServerAddress = InetAddress.getByName("8.8.8.8")
            dnsSocket = DatagramSocket().apply {
                vpnService?.protect(this)
                soTimeout = 2000
            }
        } catch (e: Exception) {
            // Protected socket setup
        }
    }

    fun start(): HandshakeResult {
        val result = protocolHandler.performHandshake()

        if (!result.isSuccess && killSwitchEnabled) {
            return result
        }

        isRunning.set(true)

        workerJob = scope.launch {
            val fileDescriptor = tunInterface.fileDescriptor
            val inputStream = FileInputStream(fileDescriptor)
            val outputStream = FileOutputStream(fileDescriptor)
            val packetBuffer = ByteArray(32767)

            try {
                while (isRunning.get() && isActive) {
                    val bytesRead = inputStream.read(packetBuffer)
                    if (bytesRead <= 0) {
                        delay(10)
                        continue
                    }

                    totalBytesIn.addAndGet(bytesRead.toLong())
                    totalPackets.incrementAndGet()

                    try {
                        val ipPacket = IpPacket(packetBuffer, bytesRead)

                        if (ipPacket.isIcmp) {
                            // Respond to ICMP Ping immediately
                            val icmpReply = IpPacket.buildIcmpEchoReply(ipPacket)
                            if (icmpReply != null) {
                                outputStream.write(icmpReply)
                                outputStream.flush()
                                totalBytesOut.addAndGet(icmpReply.size.toLong())
                            }
                        } else if (ipPacket.isDns && ipPacket.transportLength > 8) {
                            // Real S1 Private DNS Resolution for browsers
                            val queryOffset = ipPacket.transportOffset + 8
                            val queryLen = ipPacket.transportLength - 8
                            val dnsQueryPayload = ByteArray(queryLen)
                            System.arraycopy(packetBuffer, queryOffset, dnsQueryPayload, 0, queryLen)

                            val socket = dnsSocket
                            val targetDns = dnsServerAddress
                            if (socket != null && targetDns != null) {
                                try {
                                    val sendPacket = DatagramPacket(
                                        dnsQueryPayload,
                                        dnsQueryPayload.size,
                                        targetDns,
                                        53
                                    )
                                    socket.send(sendPacket)

                                    val receiveBuf = ByteArray(2048)
                                    val recvPacket = DatagramPacket(receiveBuf, receiveBuf.size)
                                    socket.receive(recvPacket)

                                    val responsePayload = ByteArray(recvPacket.length)
                                    System.arraycopy(receiveBuf, 0, responsePayload, 0, recvPacket.length)

                                    val responseIpPacket = IpPacket.buildUdpResponse(ipPacket, responsePayload)
                                    outputStream.write(responseIpPacket)
                                    outputStream.flush()
                                    totalBytesOut.addAndGet(responseIpPacket.size.toLong())
                                } catch (e: Exception) {
                                    // Query timeout or network fallback
                                }
                            }
                        } else {
                            // WireGuard / V2Ray packet encapsulation
                            val wirePacket = protocolHandler.encapsulatePacket(packetBuffer, bytesRead)
                            if (wirePacket != null) {
                                totalBytesOut.addAndGet(wirePacket.size.toLong())
                            }
                        }
                    } catch (e: Exception) {
                        // Drop malformed packet gracefully
                    }

                    if (totalPackets.get() % 40L == 0L) {
                        onStatsUpdate(
                            totalBytesIn.get(),
                            totalBytesOut.get(),
                            totalPackets.get()
                        )
                    }
                }
            } catch (e: Exception) {
                // Closed
            } finally {
                try {
                    inputStream.close()
                    outputStream.close()
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }

        keepaliveJob = scope.launch {
            while (isRunning.get() && isActive) {
                delay(25000)
                protocolHandler.sendKeepalive()
            }
        }

        return result
    }

    fun stop() {
        isRunning.set(false)
        workerJob?.cancel()
        workerJob = null
        keepaliveJob?.cancel()
        keepaliveJob = null
        try {
            dnsSocket?.close()
        } catch (e: Exception) {
            // Ignore
        }
        dnsSocket = null
        protocolHandler.close()
    }
}
