package com.example.service.protocol.wireguard

import android.util.Base64
import java.security.SecureRandom

data class WireGuardKeyPair(
    val privateKey: String,
    val publicKey: String
)

object WireGuardKeyGenerator {

    private val random = SecureRandom()

    /**
     * Generates a 32-byte WireGuard private key and simulated public key (Curve25519)
     */
    fun generateKeyPair(): WireGuardKeyPair {
        val privateBytes = ByteArray(32)
        random.nextBytes(privateBytes)
        // Curve25519 clamping
        privateBytes[0] = (privateBytes[0].toInt() and 248).toByte()
        privateBytes[31] = (privateBytes[31].toInt() and 127).toByte()
        privateBytes[31] = (privateBytes[31].toInt() or 64).toByte()

        val publicBytes = ByteArray(32)
        random.nextBytes(publicBytes)

        val privBase64 = Base64.encodeToString(privateBytes, Base64.NO_WRAP)
        val pubBase64 = Base64.encodeToString(publicBytes, Base64.NO_WRAP)

        return WireGuardKeyPair(privBase64, pubBase64)
    }

    /**
     * Generates the ready-to-use Ubuntu Server wg0.conf
     */
    fun generateServerConfig(
        serverPrivateKey: String,
        clientPublicKey: String,
        listenPort: Int = 51820
    ): String {
        return """
[Interface]
Address = 10.0.0.1/24
SaveConfig = true
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
ListenPort = $listenPort
PrivateKey = $serverPrivateKey

[Peer]
PublicKey = $clientPublicKey
AllowedIPs = 10.0.0.2/32
        """.trimIndent()
    }

    /**
     * Generates the client configuration matching the user's diagram
     */
    fun generateClientConfig(
        clientPrivateKey: String,
        serverPublicKey: String,
        serverEndpoint: String = "160.200.2.1:51820"
    ): String {
        return """
[Interface]
PrivateKey = $clientPrivateKey
Address = 10.0.0.2/24
DNS = 8.8.8.8, 8.8.4.4
MTU = 1420

[Peer]
PublicKey = $serverPublicKey
Endpoint = $serverEndpoint
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
        """.trimIndent()
    }
}
