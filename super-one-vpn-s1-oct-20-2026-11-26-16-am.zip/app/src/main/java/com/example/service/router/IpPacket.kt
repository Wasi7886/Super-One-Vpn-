package com.example.service.router

import java.net.InetAddress
import java.nio.ByteBuffer

/**
 * Lightweight IPv4 packet parser and generator for Android VpnService TUN interface.
 */
class IpPacket(val rawData: ByteArray, val length: Int) {

    val version: Int
    val headerLength: Int
    val totalLength: Int
    val protocol: Int
    val sourceIp: InetAddress
    val destIp: InetAddress

    val transportOffset: Int
    val transportLength: Int

    var sourcePort: Int = 0
        private set
    var destPort: Int = 0
        private set

    init {
        val buffer = ByteBuffer.wrap(rawData, 0, length)
        val firstByte = buffer.get(0).toInt() and 0xFF
        version = firstByte shr 4
        headerLength = (firstByte and 0x0F) * 4

        totalLength = buffer.getShort(2).toInt() and 0xFFFF
        protocol = buffer.get(9).toInt() and 0xFF

        val srcBytes = ByteArray(4)
        val dstBytes = ByteArray(4)
        System.arraycopy(rawData, 12, srcBytes, 0, 4)
        System.arraycopy(rawData, 16, dstBytes, 0, 4)

        sourceIp = InetAddress.getByAddress(srcBytes)
        destIp = InetAddress.getByAddress(dstBytes)

        transportOffset = headerLength
        transportLength = (length - headerLength).coerceAtLeast(0)

        if (transportLength >= 4) {
            when (protocol) {
                PROTOCOL_UDP, PROTOCOL_TCP -> {
                    sourcePort = buffer.getShort(transportOffset).toInt() and 0xFFFF
                    destPort = buffer.getShort(transportOffset + 2).toInt() and 0xFFFF
                }
            }
        }
    }

    val isUdp: Boolean get() = protocol == PROTOCOL_UDP
    val isTcp: Boolean get() = protocol == PROTOCOL_TCP
    val isIcmp: Boolean get() = protocol == PROTOCOL_ICMP
    val isDns: Boolean get() = isUdp && (destPort == 53 || sourcePort == 53)

    /**
     * Checks if this packet is likely WhatsApp VoIP or media traffic (UDP high ports)
     */
    val isVoipUdp: Boolean
        get() = isUdp && (destPort in 3478..3481 || destPort in 5000..60000)

    companion object {
        const val PROTOCOL_ICMP = 1
        const val PROTOCOL_TCP = 6
        const val PROTOCOL_UDP = 17

        /**
         * Builds an ICMP Echo Reply in response to an Echo Request (Ping)
         */
        fun buildIcmpEchoReply(request: IpPacket): ByteArray? {
            if (!request.isIcmp || request.length < 28) return null

            val reply = request.rawData.copyOf(request.length)
            val buffer = ByteBuffer.wrap(reply)

            // Swap Source and Destination IPs
            System.arraycopy(request.rawData, 16, reply, 12, 4)
            System.arraycopy(request.rawData, 12, reply, 16, 4)

            // Recalculate IP Header Checksum
            reply[10] = 0
            reply[11] = 0
            val ipChecksum = computeChecksum(reply, 0, request.headerLength)
            buffer.putShort(10, ipChecksum.toShort())

            // Modify ICMP Type: change from 8 (Request) to 0 (Reply)
            val icmpOffset = request.transportOffset
            reply[icmpOffset] = 0 // Type = 0 (Echo Reply)

            // Recalculate ICMP Checksum
            reply[icmpOffset + 2] = 0
            reply[icmpOffset + 3] = 0
            val icmpChecksum = computeChecksum(reply, icmpOffset, request.transportLength)
            buffer.putShort(icmpOffset + 2, icmpChecksum.toShort())

            return reply
        }

        /**
         * Builds an IPv4 UDP response packet (e.g. for DNS query resolution)
         */
        fun buildUdpResponse(request: IpPacket, responsePayload: ByteArray): ByteArray {
            val ipHeaderLen = 20
            val udpHeaderLen = 8
            val totalLen = ipHeaderLen + udpHeaderLen + responsePayload.size

            val packet = ByteArray(totalLen)
            val buffer = ByteBuffer.wrap(packet)

            // IP Header (20 bytes)
            buffer.put(0x45.toByte()) // IPv4, 20 bytes
            buffer.put(0.toByte()) // ToS
            buffer.putShort(totalLen.toShort())
            buffer.putShort(0x1A2B.toShort()) // Identification
            buffer.putShort(0x4000.toShort()) // Flags (Don't Fragment)
            buffer.put(64.toByte()) // TTL
            buffer.put(PROTOCOL_UDP.toByte()) // Protocol 17
            buffer.putShort(0) // Checksum placeholder

            // Swap IPs: Source is request.destIp, Dest is request.sourceIp
            buffer.put(request.destIp.address)
            buffer.put(request.sourceIp.address)

            // Calculate and set IP checksum
            val ipChecksum = computeChecksum(packet, 0, ipHeaderLen)
            buffer.putShort(10, ipChecksum.toShort())

            // UDP Header (8 bytes): swap ports
            buffer.putShort(request.destPort.toShort()) // Source Port (e.g. 53)
            buffer.putShort(request.sourcePort.toShort()) // Dest Port
            buffer.putShort((udpHeaderLen + responsePayload.size).toShort()) // UDP Length
            buffer.putShort(0) // Optional UDP Checksum (0 = omitted in IPv4 UDP)

            // UDP Payload
            buffer.put(responsePayload)

            return packet
        }

        private fun computeChecksum(data: ByteArray, offset: Int, length: Int): Int {
            var sum = 0
            var i = offset
            val end = offset + length

            while (i < end - 1) {
                val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
                sum += word
                i += 2
            }

            if (i < end) {
                sum += (data[i].toInt() and 0xFF) shl 8
            }

            while (sum shr 16 != 0) {
                sum = (sum and 0xFFFF) + (sum shr 16)
            }

            return sum.inv() and 0xFFFF
        }
    }
}
