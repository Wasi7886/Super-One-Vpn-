package com.example.service

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.example.MainActivity
import com.example.R
import com.example.data.ConnectionStatus
import com.example.data.VpnRepository

@RequiresApi(Build.VERSION_CODES.N)
class S1TileService : TileService() {

    private val repository by lazy { VpnRepository.getInstance(applicationContext) }

    override fun onTileAdded() {
        super.onTileAdded()
        updateTileState()
    }

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()

        // Check if VPN permission has been prepared
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            val appIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pending = PendingIntent.getActivity(
                    this, 0, appIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pending)
            } else {
                startActivityAndCollapse(appIntent)
            }
            return
        }

        val currentStatus = repository.uiState.value.status
        if (currentStatus == ConnectionStatus.CONNECTED) {
            repository.disconnect()
        } else if (currentStatus == ConnectionStatus.DISCONNECTED) {
            repository.connect()
        }
        updateTileState()
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        val status = repository.uiState.value.status
        val server = repository.uiState.value.selectedServer

        when (status) {
            ConnectionStatus.CONNECTED -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = "S1 VPN"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "${server.country} • Protected"
                }
                tile.contentDescription = "S1 VPN Connected - Tap to Disconnect"
                tile.icon = Icon.createWithResource(this, R.drawable.ic_vpn_tile)
            }
            ConnectionStatus.CONNECTING -> {
                tile.state = Tile.STATE_UNAVAILABLE
                tile.label = "S1 VPN"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "Connecting..."
                }
                tile.contentDescription = "S1 VPN Connecting"
                tile.icon = Icon.createWithResource(this, R.drawable.ic_vpn_tile)
            }
            ConnectionStatus.DISCONNECTED, ConnectionStatus.DISCONNECTING -> {
                tile.state = Tile.STATE_INACTIVE
                tile.label = "S1 VPN"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "Disconnected"
                }
                tile.contentDescription = "S1 VPN Disconnected - Tap to Connect"
                tile.icon = Icon.createWithResource(this, R.drawable.ic_vpn_tile)
            }
        }
        tile.updateTile()
    }
}
