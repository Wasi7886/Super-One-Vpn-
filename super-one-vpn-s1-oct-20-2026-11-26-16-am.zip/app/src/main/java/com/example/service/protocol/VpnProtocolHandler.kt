package com.example.service.protocol

import android.net.VpnService

data class ProtocolConfig(
    val serverIp: String = "103.45.122.88",
    val serverPort: Int = 51820,
    val clientPrivateKey: String = "S1ClientPrivateKeyBase64DefaultGenerated==",
    val serverPublicKey: String = "S1ServerPublicKeyBase64DefaultGenerated==",
    val presharedKey: String? = null,
    val uuid: String = "e3b0c442-98fc-1c14-9afbf4c8996fb924",
    val mtu: Int = 1420,
    val keepaliveSeconds: Int = 25,
    val cipher: String = "ChaCha20-Poly1305"
)

data class HandshakeResult(
    val isSuccess: Boolean,
    val latencyMs: Long,
    val protocolName: String,
    val cipherSuite: String,
    val sessionId: Long = 0L,
    val errorMessage: String? = null
)

interface VpnProtocolHandler {
    val protocolName: String

    fun initialize(config: ProtocolConfig, vpnService: VpnService? = null)

    /**
     * Performs cryptographic handshake with the remote endpoint.
     */
    fun performHandshake(): HandshakeResult

    /**
     * Encapsulates raw IP packet from TUN into encrypted protocol wire format
     */
    fun encapsulatePacket(packet: ByteArray, length: Int): ByteArray?

    /**
     * Decapsulates incoming wire packet from remote server back to raw IP packet
     */
    fun decapsulatePacket(packet: ByteArray, length: Int): ByteArray?

    /**
     * Sends keepalive heartbeat packet if required by protocol
     */
    fun sendKeepalive(): ByteArray?

    /**
     * Releases sockets and cryptographic state
     */
    fun close()
}
