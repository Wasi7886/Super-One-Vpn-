package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.service.protocol.wireguard.WireGuardKeyGenerator
import com.example.ui.theme.S1GreenAccent
import com.example.ui.theme.S1GreenPrimary
import com.example.ui.theme.S1TextSecondary
import com.example.ui.theme.S1TextWhite

@Composable
fun WireGuardConfigDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var clientKeys by remember { mutableStateOf(WireGuardKeyGenerator.generateKeyPair()) }
    var serverKeys by remember { mutableStateOf(WireGuardKeyGenerator.generateKeyPair()) }

    val serverConfig = remember(clientKeys, serverKeys) {
        WireGuardKeyGenerator.generateServerConfig(
            serverPrivateKey = serverKeys.privateKey,
            clientPublicKey = clientKeys.publicKey
        )
    }

    val clientConfig = remember(clientKeys, serverKeys) {
        WireGuardKeyGenerator.generateClientConfig(
            clientPrivateKey = clientKeys.privateKey,
            serverPublicKey = serverKeys.publicKey,
            serverEndpoint = "160.200.2.1:51820"
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF13171F))
                .border(1.dp, Color(0xFF2B3340), RoundedCornerShape(24.dp))
                .padding(20.dp)
                .testTag("wireguard_config_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(S1GreenPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = null,
                                tint = S1GreenAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "WireGuard Server & Keys",
                            color = S1TextWhite,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = S1TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Network Topology Info from user diagram
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0C0F14))
                        .border(1.dp, Color(0xFF232B36), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Dns, contentDescription = null, tint = S1GreenAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ubuntu VPS Server • 160.200.2.1:51820",
                                color = S1GreenAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• Client VPN IP: 10.0.0.2/24\n• Server VPN IP: 10.0.0.1/24\n• DNS: 8.8.8.8, 8.8.4.4\n• MTU: 1420",
                            color = S1TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Regenerate Keys Button
                OutlinedButton(
                    onClick = {
                        clientKeys = WireGuardKeyGenerator.generateKeyPair()
                        serverKeys = WireGuardKeyGenerator.generateKeyPair()
                        Toast.makeText(context, "New WireGuard Keys Generated!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Autorenew, contentDescription = null, tint = S1GreenAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Regenerate WireGuard Keys", color = S1GreenAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Section 1: Ubuntu VPS Server Config (/etc/wireguard/wg0.conf)
                ConfigCodeCard(
                    title = "Ubuntu VPS Config (/etc/wireguard/wg0.conf)",
                    content = serverConfig,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(serverConfig))
                        Toast.makeText(context, "Copied Ubuntu Server Config!", Toast.LENGTH_SHORT).show()
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Section 2: Android Client Config (wg0-client.conf)
                ConfigCodeCard(
                    title = "Android Client Config (wg0-client.conf)",
                    content = clientConfig,
                    onCopy = {
                        clipboardManager.setText(AnnotatedString(clientConfig))
                        Toast.makeText(context, "Copied Client Config!", Toast.LENGTH_SHORT).show()
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = S1GreenPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "Done", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun ConfigCodeCard(
    title: String,
    content: String,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0C0E14))
            .border(1.dp, Color(0xFF222935), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = S1TextWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy",
                    tint = S1GreenAccent,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = content,
            color = Color(0xFFB0BEC5),
            fontSize = 10.sp,
            lineHeight = 14.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
