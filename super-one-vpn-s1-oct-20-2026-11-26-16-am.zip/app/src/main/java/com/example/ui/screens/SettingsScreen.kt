package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VpnSettings
import com.example.ui.components.PremiumModal
import com.example.ui.components.QuickSettingsTileDialog
import com.example.ui.components.WireGuardConfigDialog
import com.example.ui.theme.S1CardDark
import com.example.ui.theme.S1GreenAccent
import com.example.ui.theme.S1GreenPrimary
import com.example.ui.theme.S1TextSecondary
import com.example.ui.theme.S1TextWhite

@Composable
fun SettingsScreen(
    settings: VpnSettings,
    onKillSwitchChange: (Boolean) -> Unit,
    onAutoConnectChange: (Boolean) -> Unit,
    onNotificationsChange: (Boolean) -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onS1TurboModeChange: (Boolean) -> Unit,
    onProtocolChange: (String) -> Unit,
    onUpgradeToPremium: () -> Unit,
    onNavigateBack: () -> Unit
) {
    BackHandler {
        onNavigateBack()
    }

    var showTileDialog by remember { mutableStateOf(false) }
    var showPremiumModal by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showWireGuardConfigDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090B0E))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("settings_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF161A22))
                        .testTag("back_button_settings")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = S1TextWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Text(
                    text = "Settings",
                    color = S1TextWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION 1: CONTROL CENTRE
            SectionHeader(title = "CONTROL CENTRE")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF232832), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = S1CardDark)
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    // Kill Switch
                    SettingsToggleRow(
                        icon = Icons.Default.Shield,
                        title = "Kill Switch",
                        subtitle = "Blocks internet if VPN disconnects",
                        checked = settings.killSwitch,
                        onCheckedChange = onKillSwitchChange,
                        testTag = "kill_switch_toggle"
                    )

                    SettingsDivider()

                    // Auto Connect
                    SettingsToggleRow(
                        icon = Icons.Default.Autorenew,
                        title = "Auto Connect",
                        subtitle = "Connect automatically on insecure Wi-Fi",
                        checked = settings.autoConnectWifi,
                        onCheckedChange = onAutoConnectChange,
                        testTag = "auto_connect_toggle"
                    )

                    SettingsDivider()

                    // Quick Settings Tile
                    SettingsActionRow(
                        icon = Icons.Default.TouchApp,
                        title = "Control Centre Tile",
                        subtitle = "Add S1 VPN button to Android Quick Settings",
                        actionBadge = "Active",
                        onClick = { showTileDialog = true }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION 2: SPEED & TUNNEL (Requested S1 Turbo Speed Booster feature)
            SectionHeader(title = "SPEED & TUNNEL")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF232832), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = S1CardDark)
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    // S1 Turbo - Speed Booster [ON/OFF]
                    SettingsToggleRow(
                        icon = Icons.Default.Bolt,
                        title = "S1 Turbo - Speed Booster",
                        subtitle = "WireGuard + TCP Optimization + S1 Private DNS",
                        checked = settings.s1TurboMode,
                        onCheckedChange = onS1TurboModeChange,
                        testTag = "s1_turbo_toggle"
                    )

                    SettingsDivider()

                    // Protocol selector
                    SettingsActionRow(
                        icon = Icons.Default.VpnKey,
                        title = "Protocol",
                        subtitle = if (settings.s1TurboMode) "WireGuard Turbo (Forced by S1 Turbo)" else "WireGuard • V2Ray Stealth",
                        actionBadge = if (settings.s1TurboMode) "WireGuard" else settings.protocol,
                        onClick = {
                            if (!settings.s1TurboMode) {
                                val nextProtocol = if (settings.protocol == "WireGuard") "V2Ray" else "WireGuard"
                                onProtocolChange(nextProtocol)
                            }
                        }
                    )

                    SettingsDivider()

                    // S1 Private DNS
                    SettingsActionRow(
                        icon = Icons.Default.Security,
                        title = "S1 Private DNS",
                        subtitle = "S1 Turbo DNS active (8.8.8.8 / 8.8.4.4)",
                        actionBadge = "S1 Turbo",
                        onClick = { }
                    )

                    SettingsDivider()

                    // WireGuard VPS Server Config
                    SettingsActionRow(
                        icon = Icons.Default.VpnKey,
                        title = "WireGuard VPS Config",
                        subtitle = "Ubuntu wg0.conf & Client keys (10.0.0.2)",
                        actionBadge = "Keys",
                        onClick = { showWireGuardConfigDialog = true }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION 3: ACCOUNT & PLAN
            SectionHeader(title = "ACCOUNT")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF232832), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = S1CardDark)
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    // Subscription • Super One Premium
                    SettingsActionRow(
                        icon = Icons.Default.Star,
                        title = "Subscription • Super One Premium",
                        subtitle = if (settings.isPremium) "VIP Lifetime Plan Active" else "Fastest VIP servers & Ad-Free",
                        actionBadge = if (settings.isPremium) "ACTIVE" else "PRO",
                        badgeIsGreen = true,
                        onClick = { showPremiumModal = true }
                    )

                    SettingsDivider()

                    // Notifications
                    SettingsToggleRow(
                        icon = Icons.Default.Notifications,
                        title = "Notifications",
                        subtitle = "Show VPN status in system shade",
                        checked = settings.notifications,
                        onCheckedChange = onNotificationsChange,
                        testTag = "notifications_toggle"
                    )

                    SettingsDivider()

                    // Appearance
                    SettingsActionRow(
                        icon = Icons.Default.DarkMode,
                        title = "Appearance",
                        subtitle = "Theme preference",
                        actionBadge = if (settings.isDarkMode) "Dark Mode" else "Light Mode",
                        onClick = { onDarkModeChange(!settings.isDarkMode) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SECTION 4: ABOUT
            SectionHeader(title = "ABOUT")

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, Color(0xFF232832), RoundedCornerShape(18.dp)),
                colors = CardDefaults.cardColors(containerColor = S1CardDark)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Super One VPN S1",
                        color = S1TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "App Version 2.4.1 (Build 1024)",
                        color = S1TextSecondary,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Legal",
                            color = S1GreenAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable { showPrivacyDialog = true }
                        )
                        Text(text = "•", color = S1TextSecondary)
                        Text(
                            text = "Privacy Policy",
                            color = S1GreenAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable { showPrivacyDialog = true }
                        )
                        Text(text = "•", color = S1TextSecondary)
                        Text(
                            text = "Terms",
                            color = S1GreenAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.clickable { showPrivacyDialog = true }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Close button
            OutlinedButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("logout_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = "Close Settings",
                    color = S1TextSecondary,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showTileDialog) {
        QuickSettingsTileDialog(onDismiss = { showTileDialog = false })
    }

    if (showPremiumModal) {
        PremiumModal(
            isAlreadyPremium = settings.isPremium,
            onDismiss = { showPremiumModal = false },
            onUpgrade = onUpgradeToPremium
        )
    }

    if (showPrivacyDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showPrivacyDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF14181F))
                    .border(1.dp, Color(0xFF2C323B), RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text = "Strict Zero-Logs Policy",
                        color = S1TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Super One VPN S1 operates under a strict no-logs policy. We do not store connection timestamps, source IP addresses, DNS queries, or browsing traffic. All tunnels use WireGuard ChaCha20-Poly1305 encryption with S1 Private DNS.",
                        color = S1TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    androidx.compose.material3.Button(
                        onClick = { showPrivacyDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = S1GreenPrimary
                        )
                    ) {
                        Text("Understood", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showWireGuardConfigDialog) {
        WireGuardConfigDialog(onDismiss = { showWireGuardConfigDialog = false })
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        color = S1TextSecondary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1F252E)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = S1TextWhite,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    color = S1TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = S1TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = S1GreenPrimary,
                uncheckedThumbColor = Color(0xFF758190),
                uncheckedTrackColor = Color(0xFF282F3B)
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionBadge: String,
    badgeIsGreen: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1F252E)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (badgeIsGreen) S1GreenAccent else S1TextWhite,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    color = S1TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    color = S1TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (badgeIsGreen) S1GreenPrimary.copy(alpha = 0.2f) else Color(0xFF202630)
                    )
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = actionBadge,
                    color = if (badgeIsGreen) S1GreenAccent else S1TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = S1TextSecondary,
                modifier = Modifier.size(12.dp)
            )
        }
    }
}

@Composable
private fun SettingsDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Color(0xFF20252D))
    )
}
