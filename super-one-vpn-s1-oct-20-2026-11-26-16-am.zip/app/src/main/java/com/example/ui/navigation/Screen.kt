package com.example.ui.navigation

sealed class Screen {
    object Splash : Screen()
    object Home : Screen()
    object ServerList : Screen()
    object Settings : Screen()
}
