package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = S1GreenPrimary,
    onPrimary = Color.Black,
    primaryContainer = S1GreenDark,
    onPrimaryContainer = S1GreenAccent,
    secondary = S1GreenAccent,
    onSecondary = Color.Black,
    background = S1CarbonBg,
    onBackground = S1TextWhite,
    surface = S1SurfaceDark,
    onSurface = S1TextWhite,
    surfaceVariant = S1CardDark,
    onSurfaceVariant = S1TextSecondary,
    outline = S1BorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = S1GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = S1GreenLightBg,
    onPrimaryContainer = S1GreenDark,
    secondary = S1GreenDark,
    onSecondary = Color.White,
    background = S1LightBg,
    onBackground = S1LightTextPrimary,
    surface = S1LightSurface,
    onSurface = S1LightTextPrimary,
    surfaceVariant = S1LightCard,
    onSurfaceVariant = S1LightTextSecondary,
    outline = S1LightBorder
)

@Composable
fun SuperOneVpnTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
