package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VpnServer
import com.example.ui.theme.S1CardDark
import com.example.ui.theme.S1GreenAccent
import com.example.ui.theme.S1GreenPrimary
import com.example.ui.theme.S1PingFast
import com.example.ui.theme.S1PingMedium
import com.example.ui.theme.S1PingSlow
import com.example.ui.theme.S1TextSecondary
import com.example.ui.theme.S1TextWhite

@Composable
fun ServerItemCard(
    server: VpnServer,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pingColor = when {
        server.pingMs < 50 -> S1PingFast
        server.pingMs < 100 -> S1PingMedium
        else -> S1PingSlow
    }

    val cardBorder = if (isSelected) {
        Modifier.border(1.5.dp, S1GreenAccent, RoundedCornerShape(16.dp))
    } else {
        Modifier.border(1.dp, Color(0xFF232830), RoundedCornerShape(16.dp))
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(cardBorder)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isSelected) Color(0xFF131D18) else S1CardDark
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = S1GreenAccent),
                onClick = onSelect
            )
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag("server_item_${server.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Radio / Active dot indicator
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            if (isSelected) S1GreenAccent else Color(0xFF3B434E)
                        )
                )

                Spacer(modifier = Modifier.width(12.dp))

                // Flag circle/box
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF222832)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = server.flagEmoji,
                        fontSize = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = server.country,
                            color = S1TextWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (server.city.isNotEmpty() && server.city != server.country) {
                            Text(
                                text = " — ${server.city}",
                                color = S1TextSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.padding(top = 2.dp))

                    Text(
                        text = server.statusTag,
                        color = if (isSelected) S1GreenAccent else S1TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Normal
                    )
                }
            }

            // Ping badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF161A20))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(pingColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${server.pingMs} ms",
                    color = pingColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
