package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.ConnectionStatus
import com.example.ui.theme.S1GreenAccent
import com.example.ui.theme.S1GreenDark
import com.example.ui.theme.S1GreenPrimary

@Composable
fun PowerButton(
    status: ConnectionStatus,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 140.dp
) {
    val isConnected = status == ConnectionStatus.CONNECTED
    val isConnecting = status == ConnectionStatus.CONNECTING || status == ConnectionStatus.DISCONNECTING

    val infiniteTransition = rememberInfiniteTransition(label = "power_glow")

    // Ripple wave expansion when connected
    val waveScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isConnected) 1.35f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveScale"
    )

    val waveAlpha by infiniteTransition.animateFloat(
        initialValue = if (isConnected) 0.5f else 0f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "waveAlpha"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin"
    )

    val buttonScale by animateFloatAsState(
        targetValue = if (isConnecting) 0.95f else 1f,
        animationSpec = spring(dampingRatio = 0.6f),
        label = "buttonScale"
    )

    val ringColor by animateColorAsState(
        targetValue = when (status) {
            ConnectionStatus.CONNECTED -> S1GreenAccent
            ConnectionStatus.CONNECTING -> S1GreenPrimary
            ConnectionStatus.DISCONNECTING -> Color(0xFFFFB300)
            ConnectionStatus.DISCONNECTED -> Color(0xFF2D333B)
        },
        animationSpec = tween(400),
        label = "ringColor"
    )

    Box(
        modifier = modifier
            .size(size * 1.5f)
            .testTag("power_button_container"),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing wave when connected
        if (isConnected) {
            Box(
                modifier = Modifier
                    .size(size)
                    .scale(waveScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                S1GreenAccent.copy(alpha = waveAlpha),
                                S1GreenPrimary.copy(alpha = waveAlpha * 0.4f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        // Connecting circular progress spinner ring
        if (isConnecting) {
            CircularProgressIndicator(
                modifier = Modifier
                    .size(size + 16.dp)
                    .rotate(rotation),
                color = S1GreenAccent,
                strokeWidth = 3.dp,
                trackColor = Color(0x3300E676)
            )
        }

        // Main button
        Box(
            modifier = Modifier
                .size(size)
                .scale(buttonScale)
                .shadow(
                    elevation = if (isConnected) 24.dp else 8.dp,
                    shape = CircleShape,
                    ambientColor = if (isConnected) S1GreenAccent else Color.Black,
                    spotColor = if (isConnected) S1GreenAccent else Color.Black
                )
                .clip(CircleShape)
                .background(
                    if (isConnected) {
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF00E676),
                                Color(0xFF00C853),
                                Color(0xFF0D381E)
                            )
                        )
                    } else {
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF222830),
                                Color(0xFF161A20),
                                Color(0xFF0D0F12)
                            )
                        )
                    }
                )
                .border(
                    width = if (isConnected) 3.dp else 2.dp,
                    color = ringColor,
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = S1GreenAccent),
                    onClick = onClick
                )
                .testTag("power_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = if (isConnected) "Disconnect VPN" else "Connect VPN",
                tint = if (isConnected) Color.White else Color(0xFF758190),
                modifier = Modifier.size(size * 0.45f)
            )
        }
    }
}
