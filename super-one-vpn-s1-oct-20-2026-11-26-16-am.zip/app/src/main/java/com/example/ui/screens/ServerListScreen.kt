package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DefaultServers
import com.example.data.model.ServerCategory
import com.example.data.model.VpnServer
import com.example.ui.components.ServerItemCard
import com.example.ui.theme.S1GreenAccent
import com.example.ui.theme.S1GreenPrimary
import com.example.ui.theme.S1TextSecondary
import com.example.ui.theme.S1TextWhite

@Composable
fun ServerListScreen(
    currentServer: VpnServer,
    onSelectServer: (VpnServer) -> Unit,
    onNavigateBack: () -> Unit
) {
    BackHandler {
        onNavigateBack()
    }

    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf<ServerCategory?>(null) }

    val allServers = DefaultServers.servers

    val filteredServers = allServers.filter { server ->
        val matchesSearch = searchQuery.isBlank() ||
                server.country.contains(searchQuery, ignoreCase = true) ||
                server.city.contains(searchQuery, ignoreCase = true) ||
                server.statusTag.contains(searchQuery, ignoreCase = true)

        val matchesCategory = selectedCategory == null ||
                selectedCategory == ServerCategory.ALL ||
                server.category == selectedCategory ||
                (selectedCategory == ServerCategory.RECOMMENDED && server.isRecommended)

        matchesSearch && matchesCategory
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090B0E))
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("server_list_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header Bar (Matching Screen 3)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF161A22))
                            .testTag("back_button_servers")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = S1TextWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Servers",
                            color = S1TextWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "127 servers • 6 recommended",
                            color = S1TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { isSearchActive = !isSearchActive },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF161A22))
                            .testTag("search_icon_button")
                    ) {
                        Icon(
                            imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                            contentDescription = "Search",
                            tint = if (isSearchActive) S1GreenAccent else S1TextWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { selectedCategory = null; searchQuery = "" },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF161A22))
                            .testTag("filter_icon_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Filter",
                            tint = S1TextWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Animated Search Input
            AnimatedVisibility(visible = isSearchActive) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("server_search_input"),
                        placeholder = {
                            Text("Search country, city, or sports...", color = S1TextSecondary, fontSize = 13.sp)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = S1TextWhite,
                            unfocusedTextColor = S1TextWhite,
                            focusedBorderColor = S1GreenAccent,
                            unfocusedBorderColor = Color(0xFF2B323D),
                            focusedContainerColor = Color(0xFF13171F),
                            unfocusedContainerColor = Color(0xFF13171F)
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category Tabs: All, Recommended, Sports & Streaming, WhatsApp & VoIP
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val categories = listOf(
                    ServerCategory.ALL to "All (127)",
                    ServerCategory.RECOMMENDED to "⚡ Recommended",
                    ServerCategory.SPORTS to "⚽ Sports & Live",
                    ServerCategory.WHATSAPP to "💬 WhatsApp & VoIP"
                )

                items(categories) { (cat, label) ->
                    val isSelected = selectedCategory == cat || (selectedCategory == null && cat == ServerCategory.ALL)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                if (isSelected) Color(0xFF102619) else Color(0xFF141820)
                            )
                            .border(
                                1.dp,
                                if (isSelected) S1GreenAccent else Color(0xFF262C36),
                                RoundedCornerShape(20.dp)
                            )
                            .clickable {
                                selectedCategory = if (cat == ServerCategory.ALL) null else cat
                            }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                            .testTag("filter_tab_${cat.name}")
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) S1GreenAccent else S1TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Server List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("server_list_recycler"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (filteredServers.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No servers found for '$searchQuery'",
                                color = S1TextSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    items(filteredServers, key = { it.id }) { server ->
                        ServerItemCard(
                            server = server,
                            isSelected = server.id == currentServer.id,
                            onSelect = {
                                onSelectServer(server)
                                onNavigateBack()
                            }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}
