package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary S1 Greens
val S1GreenPrimary = Color(0xFF00C853)
val S1GreenAccent = Color(0xFF00E676)
val S1GreenDark = Color(0xFF1B5E20)
val S1GreenGlow = Color(0x6600E676)
val S1GreenLightBg = Color(0x1A00E676)

// Dark Theme Carbon & Surfaces
val S1Black = Color(0xFF000000)
val S1CarbonBg = Color(0xFF0D0F11)
val S1SurfaceDark = Color(0xFF14171B)
val S1CardDark = Color(0xFF1B2026)
val S1CardElevatedDark = Color(0xFF222830)
val S1BorderDark = Color(0xFF2D333B)

// Text and Accents
val S1TextWhite = Color(0xFFFFFFFF)
val S1TextSecondary = Color(0xFF8B949E)
val S1TextMuted = Color(0xFF586069)
val S1Divider = Color(0xFF21262D)

// Ping and Status Indicators
val S1PingFast = Color(0xFF00E676)
val S1PingMedium = Color(0xFFFFB300)
val S1PingSlow = Color(0xFFFF5252)

// Light Theme equivalents
val S1LightBg = Color(0xFFF7F9FA)
val S1LightSurface = Color(0xFFFFFFFF)
val S1LightCard = Color(0xFFF0F4F2)
val S1LightBorder = Color(0xFFE1E4E8)
val S1LightTextPrimary = Color(0xFF0F1419)
val S1LightTextSecondary = Color(0xFF536471)
