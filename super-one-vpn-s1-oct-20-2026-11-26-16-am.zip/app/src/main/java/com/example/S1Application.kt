package com.example

import android.app.Application
import com.example.data.VpnRepository

class S1Application : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize VpnRepository
        VpnRepository.getInstance(this)
    }
}
