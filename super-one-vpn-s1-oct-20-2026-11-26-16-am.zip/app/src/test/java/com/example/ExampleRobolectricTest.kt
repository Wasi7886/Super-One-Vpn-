package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ConnectionStatus
import com.example.data.VpnRepository
import com.example.data.model.DefaultServers
import com.example.service.protocol.ProtocolConfig
import com.example.service.protocol.v2ray.V2RayProtocolHandler
import com.example.service.protocol.wireguard.WireGuardProtocolHandler
import com.example.service.router.IpPacket
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.ByteBuffer

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Super One VPN S1", appName)
    }

    @Test
    fun `default servers are loaded and recommended server is Singapore`() {
        val servers = DefaultServers.servers
        assertEquals(9, servers.size)
        val defaultServer = DefaultServers.defaultServer
        assertEquals("Singapore", defaultServer.country)
        assertEquals(12, defaultServer.pingMs)
        assertNotNull(servers.find { it.id == "wg-ubuntu" })
    }

    @Test
    fun `repository initial state is disconnected`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = VpnRepository.getInstance(context)
        assertNotNull(repo.uiState.value)
        assertEquals(ConnectionStatus.DISCONNECTED, repo.uiState.value.status)
        assertEquals("Singapore", repo.uiState.value.selectedServer.country)
    }

    @Test
    fun `s1 turbo mode is enabled by default in settings`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = VpnRepository.getInstance(context)
        assertTrue(repo.settings.value.s1TurboMode)
    }

    @Test
    fun `kill switch can be toggled in repository settings`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = VpnRepository.getInstance(context)
        repo.setKillSwitch(true)
        assertTrue(repo.settings.value.killSwitch)
        repo.setKillSwitch(false)
        assert(!repo.settings.value.killSwitch)
    }

    @Test
    fun `wireguard protocol handler completes handshake and encapsulates packet`() {
        val handler = WireGuardProtocolHandler()
        val config = ProtocolConfig(serverIp = "127.0.0.1", serverPort = 51820)
        handler.initialize(config, null)
        val handshake = handler.performHandshake()
        assertTrue(handshake.isSuccess)
        assertEquals("WireGuard", handshake.protocolName)

        val samplePacket = "HELLO_S1_VPN_TEST".toByteArray()
        val encapsulated = handler.encapsulatePacket(samplePacket, samplePacket.size)
        assertNotNull(encapsulated)
        assertTrue(encapsulated!!.isNotEmpty())
        assertEquals(WireGuardProtocolHandler.MESSAGE_DATA, encapsulated[0])

        val decapsulated = handler.decapsulatePacket(encapsulated, encapsulated.size)
        assertNotNull(decapsulated)
        assertEquals("HELLO_S1_VPN_TEST", String(decapsulated!!))
    }

    @Test
    fun `v2ray protocol handler completes handshake and chunk framing`() {
        val handler = V2RayProtocolHandler()
        val config = ProtocolConfig(serverIp = "127.0.0.1", serverPort = 443)
        handler.initialize(config, null)
        val handshake = handler.performHandshake()
        assertTrue(handshake.isSuccess)
        assertEquals("V2Ray VMess", handshake.protocolName)

        val samplePacket = "V2RAY_CHUNK_TEST".toByteArray()
        val encapsulated = handler.encapsulatePacket(samplePacket, samplePacket.size)
        assertNotNull(encapsulated)

        val decapsulated = handler.decapsulatePacket(encapsulated!!, encapsulated.size)
        assertNotNull(decapsulated)
        assertEquals("V2RAY_CHUNK_TEST", String(decapsulated!!))
    }

    @Test
    fun `ip packet parser correctly parses udp dns packet with s1 private dns`() {
        val packetBytes = ByteArray(32)
        val buffer = ByteBuffer.wrap(packetBytes)
        buffer.put(0x45.toByte())
        buffer.put(0x00.toByte())
        buffer.putShort(32.toShort())
        buffer.putShort(0x1234.toShort())
        buffer.putShort(0x0000.toShort())
        buffer.put(64.toByte())
        buffer.put(IpPacket.PROTOCOL_UDP.toByte())
        buffer.putShort(0.toShort())
        buffer.put(byteArrayOf(10, 8, 0, 2))
        buffer.put(byteArrayOf(8, 8, 8, 8)) // S1 Private DNS

        buffer.putShort(54321.toShort())
        buffer.putShort(53.toShort())
        buffer.putShort(12.toShort())
        buffer.putShort(0.toShort())
        buffer.put(byteArrayOf(0x01, 0x02, 0x03, 0x04))

        val ipPacket = IpPacket(packetBytes, packetBytes.size)
        assertEquals(4, ipPacket.version)
        assertEquals(20, ipPacket.headerLength)
        assertEquals(IpPacket.PROTOCOL_UDP, ipPacket.protocol)
        assertTrue(ipPacket.isUdp)
        assertTrue(ipPacket.isDns)
        assertEquals(54321, ipPacket.sourcePort)
        assertEquals(53, ipPacket.destPort)
        assertEquals("/8.8.8.8", ipPacket.destIp.toString())

        // Test building UDP response for browser DNS resolution
        val mockDnsAnswer = byteArrayOf(0x01, 0x02, 0x81.toByte(), 0x80.toByte())
        val responseBytes = IpPacket.buildUdpResponse(ipPacket, mockDnsAnswer)
        val parsedResponse = IpPacket(responseBytes, responseBytes.size)
        assertEquals("/10.8.0.2", parsedResponse.destIp.toString())
        assertEquals("/8.8.8.8", parsedResponse.sourceIp.toString())
        assertEquals(53, parsedResponse.sourcePort)
        assertEquals(54321, parsedResponse.destPort)
    }

    @Test
    fun `vpn diagnostic utility runs and returns valid recommendations`() {
        val result = com.example.service.VpnDiagnosticUtility.runDiagnostics()
        assertNotNull(result)
        assertTrue(result.suggestedMtu > 0)
        assertTrue(result.diagnosticMessage.isNotEmpty())
    }

    @Test
    fun `wireguard key generator creates valid keys and configs`() {
        val keys = com.example.service.protocol.wireguard.WireGuardKeyGenerator.generateKeyPair()
        assertNotNull(keys.privateKey)
        assertNotNull(keys.publicKey)
        assertTrue(keys.privateKey.isNotEmpty())
        assertTrue(keys.publicKey.isNotEmpty())

        val serverConfig = com.example.service.protocol.wireguard.WireGuardKeyGenerator.generateServerConfig(
            keys.privateKey, keys.publicKey
        )
        assertTrue(serverConfig.contains("Address = 10.0.0.1/24"))
        assertTrue(serverConfig.contains("AllowedIPs = 10.0.0.2/32"))
    }
}
